/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

uint8 buffer[512], length;

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    USB_Start(0, USB_3V_OPERATION); // Start the USB peripheral
    while(!USB_GetConfiguration()); // Wait until USB is configured
    USB_EnableOutEP(2); // Enable our output endpoint (EP2);
    for(;;)
    {
        while(USB_GetEPState(2) == USB_OUT_BUFFER_EMPTY);   // Wait until we have data
        length = USB_GetEPCount(2);                         // Get the length of received data
        USB_ReadOutEP(2, buffer, length);                   // Get the data
        while(USB_GetEPState(1) != USB_IN_BUFFER_EMPTY);    // Wait until our IN EP is empty
        USB_LoadInEP(1, buffer, length);                    // Echo the data back into the buffer
    }
}

/* [] END OF FILE */
